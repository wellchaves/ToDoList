package br.senai.sp.informatica.todolist.rest;

import java.awt.JobAttributes;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.senai.sp.informatica.todolist.dao.ListDao;
import br.senai.sp.informatica.todolist.modelo.ItemLista;
import br.senai.sp.informatica.todolist.modelo.Lista;


@RestController
public class ListRestController {

	@Autowired
	ListDao listDao;
	Lista lista;
	
	@Transactional
	@RequestMapping(value = "/lista", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Lista> salvar(@RequestBody String json) {
		String retorno = null;
		JSONObject job;
		/* recebendo o Json */
		try {
			job = new JSONObject(json);
			lista = converterJsonLista(job);
			listDao.inserir(lista);
			URI location = new URI("/todo/" + lista.getId().toString());
			//retorno do status code e o objeto lista
			return ResponseEntity.created(location).body(lista);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/* Convertendo o Json para um objeto lista */
	private Lista converterJsonLista(JSONObject job) throws JSONException {
		Lista l = new Lista();
		//l.setId(job.getLong("id"));
		l.setTitulo(job.getString("titulo"));
		l.setItens(converterJsonItem(job.optJSONArray("itens"), l));

		return l;
	}

	/* Convertendo o Json para ItemLista */
	private List<ItemLista> converterJsonItem(JSONArray array, Lista l) throws JSONException {
		List<ItemLista> list = new ArrayList<>();
		ItemLista i = null;
		System.out.println(array.length());
		for (int x = 0; x < array.length(); x++) {
			i = new ItemLista();
			//i.setId(job.getLong("id"));
			i.setDescricao(array.getString(x));
			//i.setFeito(job.getBoolean("feito"));
			i.setLista(l);
			list.add(i);
		}

		return list;
	}
}
