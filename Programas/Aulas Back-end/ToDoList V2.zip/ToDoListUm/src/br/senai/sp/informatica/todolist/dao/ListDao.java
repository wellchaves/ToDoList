package br.senai.sp.informatica.todolist.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.senai.sp.informatica.todolist.modelo.Lista;

@Repository
public class ListDao {

	@PersistenceContext
	private EntityManager manager;
	
	public void inserir(Lista lista){
		manager.persist(lista);
	}
	
	public void alterar(Lista lista){
		manager.merge(lista);
	}
	
	public Lista buscarId(Long id){
		return manager.find(Lista.class, id);
	}
	
	public void excluir(Long id){
		Lista l = buscarId(id);
		manager.remove(l);
	}
	
	public List<Lista> buscarTodos(){
		TypedQuery<Lista> query = manager.createQuery("SELECT l FROM Lista l", Lista.class);
		
		return query.getResultList();
	}
	
}
