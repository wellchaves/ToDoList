package br.senai.sp.informatica.todolist.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import br.senai.sp.informatica.todolist.modelo.ItemLista;

@Repository
public class ItemListDao {

	@PersistenceContext
	private EntityManager manager;
	
	public void inserir(ItemLista item){
		manager.persist(item);
		
	}
	
	public ItemLista buscarId(Long id){
		return manager.find(ItemLista.class, id);
	}
	
	public void excluir(Long id){
		ItemLista il = buscarId(id);
		manager.remove(il);
	}
	
	public void alterar(ItemLista item){
		manager.merge(item);
	}
	
	public List<ItemLista> buscarTodo(){
		TypedQuery<ItemLista> query = manager.createQuery("SELECT i FROM ItemLista i", ItemLista.class);
		return query.getResultList();
	}
}
